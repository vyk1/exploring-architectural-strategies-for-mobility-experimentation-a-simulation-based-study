chown vyk *.pdf

chmod 777 .
